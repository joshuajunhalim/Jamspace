-- Boiler Rooms: Supabase schema. Paste into Supabase > SQL Editor > Run (once).
-- All booking rules are enforced here, on the server. The browser only calls these functions.

create extension if not exists pgcrypto;

-- ---------- tables ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  first_name text not null default '',
  role text not null default 'student' check (role in ('student','staff')),
  created_at timestamptz not null default now()
);

create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  date date not null,
  room smallint not null check (room in (0,1)),            -- 0 = Room 1, 1 = Room 2
  slot smallint not null check (slot between 0 and 7),     -- 0 = 9:00 AM ... 7 = 7:30 PM (90 min each)
  people smallint not null check (people between 1 and 8),
  first_name text not null,
  checked_in boolean not null default false,
  status text not null default 'active' check (status in ('active','cancelled','released')),
  created_at timestamptz not null default now()
);
create unique index bookings_one_active on public.bookings (date, room, slot) where status = 'active';
create index bookings_user on public.bookings (user_id, date);

create table public.weekly_closed (                         -- slots closed every WEEKDAY (weekends are always open)
  room smallint check (room in (0,1)),
  slot smallint check (slot between 0 and 7),
  primary key (room, slot)
);
insert into public.weekly_closed values (0,1),(0,2),(0,3),(0,4);  -- Room 1: 10:30 AM - 4:30 PM

create table public.closures (                              -- one-off closed dates (room -1 = both rooms)
  id uuid primary key default gen_random_uuid(),
  date date not null,
  room smallint not null check (room in (-1,0,1)),
  reason text not null default '' check (length(reason) <= 60)
);

create table public.help_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  topic text not null check (topic in ('Broken/missing gear','Reservation help','Contact the office','Other')),
  message text not null check (length(message) between 1 and 1000),
  name text not null default '',
  email text not null default '',
  resolved boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- helpers ----------
create function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'staff')
$$;

create function public.slot_start(d date, s int) returns timestamptz
language sql stable as $$
  select ((d + time '09:00' + s * interval '90 minutes') at time zone 'America/Indiana/Indianapolis')
$$;

-- ---------- only @purdue.edu accounts, and auto-create profiles ----------
create function public.check_purdue_email() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.email is null or lower(new.email) !~ '^[^@[:space:]]+@purdue\.edu$' then
    raise exception 'Please use your @purdue.edu email.';
  end if;
  return new;
end $$;
create trigger purdue_only before insert on auth.users
  for each row execute function public.check_purdue_email();

create function public.create_profile() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email) values (new.id, lower(new.email));
  return new;
end $$;
create trigger profile_on_signup after insert on auth.users
  for each row execute function public.create_profile();

-- ---------- what other students may see: first name only, never user ids or emails ----------
create view public.public_bookings as
  select id, date, room, slot, first_name, people, checked_in, (user_id = auth.uid()) as mine
  from public.bookings
  where status = 'active' and date >= current_date - 1;

-- ---------- row level security ----------
alter table public.profiles       enable row level security;
alter table public.bookings       enable row level security;
alter table public.weekly_closed  enable row level security;
alter table public.closures       enable row level security;
alter table public.help_requests  enable row level security;

create policy profile_read   on public.profiles for select to authenticated using (id = auth.uid() or public.is_staff());
create policy profile_update on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
revoke update on public.profiles from authenticated;
grant  update (first_name) on public.profiles to authenticated;     -- nobody can change their own role

create policy booking_read on public.bookings for select to authenticated using (user_id = auth.uid() or public.is_staff());
revoke insert, update, delete on public.bookings from anon, authenticated;   -- writes only via the functions below

create policy wc_read  on public.weekly_closed for select to authenticated using (true);
create policy wc_staff on public.weekly_closed for all    to authenticated using (public.is_staff()) with check (public.is_staff());
create policy cl_read  on public.closures      for select to authenticated using (true);
create policy cl_staff on public.closures      for all    to authenticated using (public.is_staff()) with check (public.is_staff());

create policy help_insert on public.help_requests for insert to authenticated with check (user_id = auth.uid());
create policy help_read   on public.help_requests for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy help_staff_u on public.help_requests for update to authenticated using (public.is_staff()) with check (public.is_staff());
create policy help_staff_d on public.help_requests for delete to authenticated using (public.is_staff());

revoke all on public.public_bookings from anon;
grant select on public.public_bookings to authenticated;

-- ---------- booking functions ----------
create function public.create_booking(p_date date, p_room int, p_slot int, p_people int, p_first text)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  me uuid := auth.uid();
  st timestamptz; en timestamptz; wk date; n int; ex record; nid uuid; nm text;
begin
  if me is null then raise exception 'Please sign in first.'; end if;
  if p_date is null or p_room not in (0,1) or p_slot not between 0 and 7 or p_people not between 1 and 8 then
    raise exception 'Invalid booking details.';
  end if;
  nm := left(btrim(coalesce(p_first, '')), 30);
  if nm = '' then raise exception 'Please add your first name.'; end if;
  st := public.slot_start(p_date, p_slot);
  en := st + interval '90 minutes';

  perform pg_advisory_xact_lock(hashtext(me::text));                        -- no double-submits
  perform pg_advisory_xact_lock(hashtext(p_date::text || p_room || ':' || p_slot));

  if extract(isodow from p_date) not in (6,7)
     and exists (select 1 from weekly_closed where room = p_room and slot = p_slot) then
    raise exception 'That slot is closed.';
  end if;
  if exists (select 1 from closures where date = p_date and (room = -1 or room = p_room)) then
    raise exception 'That room is closed on that date.';
  end if;

  select * into ex from bookings where date = p_date and room = p_room and slot = p_slot and status = 'active';
  if found then
    -- auto-release: no check-in within 15 minutes of the start frees the slot
    if not ex.checked_in and now() > st + interval '15 minutes' and now() < en then
      update bookings set status = 'released' where id = ex.id;
    else
      raise exception 'Sorry, that slot was just taken. Please pick another.';
    end if;
  elsif st <= now() then
    raise exception 'That time has already started.';
  end if;

  wk := p_date - extract(dow from p_date)::int;                             -- week = Sunday..Saturday
  select count(*) into n from bookings
    where user_id = me and status in ('active','released') and date between wk and wk + 6;
  if n >= 2 then raise exception 'You can book up to 2 slots per week (Sunday-Saturday).'; end if;

  select count(*) into n from bookings
    where user_id = me and status = 'active' and public.slot_start(date, slot) + interval '90 minutes' > now();
  if n >= 6 then raise exception 'You can have up to 6 upcoming reservations.'; end if;

  insert into bookings (user_id, date, room, slot, people, first_name)
    values (me, p_date, p_room, p_slot, p_people, nm) returning id into nid;
  return nid;
exception when unique_violation then
  raise exception 'Sorry, that slot was just taken. Please pick another.';
end $$;

create function public.cancel_booking(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  update bookings set status = 'cancelled'
   where id = p_id and status = 'active' and (user_id = auth.uid() or public.is_staff());
  if not found then raise exception 'Booking not found.'; end if;
end $$;

create function public.check_in(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  update bookings set checked_in = true
   where id = p_id and user_id = auth.uid() and status = 'active'
     and now() between public.slot_start(date, slot) - interval '15 minutes'
                   and public.slot_start(date, slot) + interval '15 minutes';
  if not found then raise exception 'Check-in opens 15 minutes before your slot and closes 15 minutes after it starts.'; end if;
end $$;

-- ---------- usage history ----------
create function public.my_history()
returns table (date date, room smallint, slot smallint, people smallint, status text)
language sql stable security definer set search_path = public as $$
  select b.date, b.room, b.slot, b.people,
    case when b.status = 'cancelled' then 'cancelled'
         when b.status = 'released'  then 'no-show'
         when b.checked_in           then 'attended'
         else 'no-show' end
  from bookings b
  where b.user_id = auth.uid()
    and (b.status <> 'active' or public.slot_start(b.date, b.slot) + interval '90 minutes' <= now())
  order by b.date desc, b.slot desc limit 100
$$;

create function public.usage_rows()                          -- staff only, anonymous (no names or emails)
returns table (date date, room smallint, slot smallint, people smallint, status text)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_staff() then raise exception 'Staff only.'; end if;
  return query
  select b.date, b.room, b.slot, b.people,
    case when b.status = 'cancelled' then 'cancelled'
         when b.status = 'released'  then 'no-show'
         when b.checked_in           then 'attended'
         else 'no-show' end
  from bookings b
  where b.status <> 'active' or public.slot_start(b.date, b.slot) + interval '90 minutes' <= now();
end $$;

-- ---------- staff tools & privacy ----------
create function public.set_weekly_closed(p jsonb) returns void      -- p example: {"0":[1,2,3,4],"1":[]}
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_staff() then raise exception 'Staff only.'; end if;
  delete from weekly_closed where true;
  insert into weekly_closed (room, slot)
    select e.key::smallint, s.value::smallint
    from jsonb_each(p) e, jsonb_array_elements_text(e.value) as s(value);
end $$;

create function public.delete_my_data() returns void               -- removes the account and everything tied to it
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Please sign in first.'; end if;
  delete from auth.users where id = auth.uid();                     -- cascades to profile, bookings, help requests
end $$;

-- ---------- who may call what ----------
revoke execute on all functions in schema public from public, anon;
grant execute on function public.create_booking(date,int,int,int,text), public.cancel_booking(uuid),
  public.check_in(uuid), public.my_history(), public.usage_rows(), public.set_weekly_closed(jsonb),
  public.delete_my_data(), public.is_staff() to authenticated;
